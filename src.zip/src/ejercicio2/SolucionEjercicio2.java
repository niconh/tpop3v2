package ejercicio2;

public class SolucionEjercicio2 {
	
	private int cantidadTareas;
	private int cantidadInstrucciones;
		
	public SolucionEjercicio2(int cantidadTareas, int cantidadInstrucciones) {
		super();
		this.cantidadTareas = cantidadTareas;
		this.cantidadInstrucciones = cantidadInstrucciones;
	}
	
	public int getCantidadTareas() {
		return cantidadTareas;
	}
	public int getCantidadInstrucciones() {
		return cantidadInstrucciones;
	}
	
	

}
